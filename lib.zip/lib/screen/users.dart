import 'package:fb_miner/model/message_model.dart';
import 'package:flutter/material.dart';

class chatuser extends StatefulWidget {

  final Chat user;

  const chatuser({super.key, required this.user});

  @override
  State<chatuser> createState() => _chatuserState();
}

class _chatuserState extends State<chatuser> {
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.only(left: 15, right: 15, top: 15, bottom: 2),
      color: Color(0xffE4F1FF),
      child: InkWell(
        onTap: () {},
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: Color(0xffAED2FF),
            child: Icon(Icons.person),
          ),
          title: Text(widget.user.name),
          subtitle: Text(
            widget.user.about,
            maxLines: 1,
          ),
          trailing: Text(
            "12:00 PM",
            style: TextStyle(color: Colors.black54, fontSize: 15),
          ),
        ),
      ),
    );
  }
}
