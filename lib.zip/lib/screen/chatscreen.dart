// import 'package:fb_miner/provider/chat_helper.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
//
// class chatscreen extends StatefulWidget {
//
//   final String receiverUserEmail;
//   final String receiverUserId;
//
//   const chatscreen({super.key,required this.receiverUserEmail,required this.receiverUserId});
//
//   @override
//   State<chatscreen> createState() => _chatscreenState();
// }
// class _chatscreenState extends State<chatscreen> {
//
//   final TextEditingController messageController = TextEditingController();
//   final ChatProvider chatProvider = ChatProvider();
//   final FirebaseAuth firebaseAuth = FirebaseAuth.instance;
//
//   Future<void> sendmessage() async {
//     if(messageController.text.isNotEmpty){
//       await chatProvider.sendMessage(widget.receiverUserId, messageController.text);
//
//       messageController.clear();
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return const Placeholder();
//   }
// }
