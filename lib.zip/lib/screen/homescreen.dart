import 'package:fb_miner/model/APIs.dart';
import 'package:fb_miner/model/message_model.dart';
import 'package:fb_miner/screen/loginscreen.dart';
import 'package:fb_miner/screen/users.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  List<Chat> list = [];

  signOut() async {
    await Api.auth.signOut();
    await GoogleSignIn().signOut();
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => LoginScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xffAED2FF),
        title: Text("Chat App"),
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.search)),
          IconButton(onPressed: () {}, icon: Icon(Icons.add))
        ],
        elevation: 1,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          signOut();
        },
        child: Icon(Icons.logout),
      ),
      body: StreamBuilder(
          stream: Api.firestore.collection('users').snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              final data = snapshot.data?.docs;
              list = data?.map((e) => Chat.fromJson(e.data())).toList() ?? [];
            }
            return ListView.builder(
              itemCount: list.length,
              itemBuilder: (context, index) {
                return chatuser(user: list[index]);
              },
            );
          },
      ),
    );
  }
}
